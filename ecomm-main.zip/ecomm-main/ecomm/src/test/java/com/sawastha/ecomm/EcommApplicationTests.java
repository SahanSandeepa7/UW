package com.sawastha.ecomm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommApplicationTests {

    @Test
    void contextLoads() {
    }

}
